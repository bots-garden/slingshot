# extsim-manifest

This crate defines the manifest type for [Extism](https://github.com/extism/extism).

The JSON Schema definition can be found in [schema.json](https://github.com/extism/extism/blob/main/manifest/schema.json)
