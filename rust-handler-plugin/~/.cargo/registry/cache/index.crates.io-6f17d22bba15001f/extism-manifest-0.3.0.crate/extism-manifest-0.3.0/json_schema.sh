#!/usr/bin/env sh

cargo run --example json_schema --features=json_schema > schema.json
