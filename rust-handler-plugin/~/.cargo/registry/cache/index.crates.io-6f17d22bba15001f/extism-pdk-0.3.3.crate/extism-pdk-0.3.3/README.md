# Extism Rust PDK

For more information about the Rust PDK, please [visit the docs](https://extism.org/docs/write-a-plugin/rust-pdk).

Join the [Discord](https://discord.gg/cx3usBCWnc) and chat with us!
